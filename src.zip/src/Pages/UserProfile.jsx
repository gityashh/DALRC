import UserDesc from "../Components/userprofile/UserDesc";

const UserProfile = () => {
  return (
    <>
      <UserDesc/>
    </>
  );
};

export default UserProfile;