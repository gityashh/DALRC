import Pwreset from "../Components/Login/Pwreset";

const Resetpw = () => {

  return (
    <div className="w-screen h-screen flex justify-center items-center">
      <Pwreset></Pwreset>
    </div>
  );
};

export default Resetpw;