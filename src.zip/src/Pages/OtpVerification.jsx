import VerifyOtp from "../Components/Register/VerifyOtp";

const OtpVerification = () => {
  
    return (
      <div id="otpBox"> 
        <VerifyOtp></VerifyOtp>
      </div>
    );
  };
  
  export default OtpVerification;