// /frontend/src/App.jsx

import './App.css'

import AllRoutes from './Pages/AllRoutes';


function App() {
  return (
    <>
      <AllRoutes></AllRoutes>
    </>
  );
}

export default App;
